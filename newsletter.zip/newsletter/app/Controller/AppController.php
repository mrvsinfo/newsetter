<?php

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

public $uses=array('User');

public $components = array(
    'Session',
    'Cookie',
    'Auth' => array(
        'loginRedirect' => array('controller' => 'pnews', 'action' => 'index'),
        'logoutRedirect' => array('controller' => 'users', 'action' => 'login')
    )
);


public function beforeFilter() {
        //$this->Auth->allow('index', 'view');
		$this->set('username',$this->Auth->user('username'));
		$this->set('role',$this->Auth->user('role'));
		//$this->set('userview',$this->Userdetail->find('all',array('order'=>array('Userdetail.view Desc'),'limit'=>15)));
		
    }
	
public function _setErrorLayout() {
    if ($this->name == 'CakeError') { 
    $this->layout = 'error';
    }
    }
   
public  function beforeRender () {
    $this->_setErrorLayout();
    }

}
