<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class CategoriesController extends AppController {

/**
 * Controller name
 *
 * @var string
 */
	public $name = 'Categories';

/**
 * This controller does not use a model
 *
 * @var array
 */
	//public $uses = array();

	public function beforeFilter() {
        parent::beforeFilter();
        
		$this->Auth->allow(array('display','home'));
		
		
    }

/**
 * Displays a view
 *
 * @param mixed What page to display
 * @return void
 */
 public function index(){	
//$this->layout=false;

$this->set('posts', $this->Category->find('all'));
	
		}
		
public function add(){	
//$this->layout='user';	

 if ($this->request->is('post')) {
           // $this->Pnew->create();
//$this->reuest->data['Group']['userid']=$this->Auth->user('id'));
			
			//print_r($this->data);exit;
            if ($this->Category->save($this->request->data)) {
                $this->Session->setFlash(__('Your Category has been saved.'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash(__('Unable to add your Category.'));
        }//$this->layout=false;	
		}
		
public function edit($id=null){	
$post = $this->Category->findById($id);
    
    if ($this->request->is('post')) {
        $this->Category->id = $id;
        if ($this->Category->save($this->request->data)) {
            $this->Session->setFlash(__('Your Category has been updated.'));
             $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('Unable to update your Category.'));
    }

    if (!$this->request->data) {
        $this->request->data = $post;
    }
}		
		
	
	public function delete($id){
	
	 if ($this->Category->delete($id)) {
        $this->Session->setFlash(
            __('The Category with id: %s has been deleted.', h($id))
        );
        return $this->redirect(array('action' => 'index'));
    }
	
	} 
}
