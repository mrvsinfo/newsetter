<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class GroupsController extends AppController {

/**
 * Controller name
 *
 * @var string
 */
	public $name = 'Groups';

/**
 * This controller does not use a model
 *
 * @var array
 */
//	public $uses = array();

	public function beforeFilter() {
        parent::beforeFilter();
        
		$this->Auth->allow(array('display','home'));
		
		
    }

/**
 * Displays a view
 *
 * @param mixed What page to display
 * @return void
 */
public function index(){	
//$this->layout=false;	
$this->set('posts', $this->Group->find('all'));

		}
		
public function add(){	
$this->layout='user';	

 if ($this->request->is('post')) {
           // $this->Pnew->create();
$this->request->data['Group']['userid']=$this->Auth->user('id');
			
			//print_r($this->data);exit;
            if ($this->Group->save($this->request->data)) {
                $this->Session->setFlash(__('Your post has been saved.'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash(__('Unable to add your post.'));
        }//$this->layout=false;	
		}
		
public function edit($id=null){	
//$this->layout=false;	




    $post = $this->Group->findById($id);
    
    if ($this->request->is('post')) {
        $this->Group->id = $id;
        if ($this->Group->save($this->request->data)) {
            $this->Session->setFlash(__('Your Group has been updated.'));
             $this->redirect(array('action' => 'index'));
        }
        $this->Session->setFlash(__('Unable to update your post.'));
    }

    if (!$this->request->data) {
        $this->request->data = $post;
    }
		}

		
		public function editgroup($id=null){	
$this->layout='user';
	



    $post = $this->Group->findById($id);
    
    if ($this->request->is('post')) {
        $this->Group->id = $id;
        if ($this->Group->save($this->request->data)) {
            $this->Session->setFlash(__('Your Group has been updated.'));
             $this->redirect(array('action' => 'usergroup'));
        }
        $this->Session->setFlash(__('Unable to update your post.'));
    }

    if (!$this->request->data) {
        $this->request->data = $post;
    }
		}
	
	public function usergroup(){
	$this->layout='user';
	$userid=$this->Auth->user('id');
	$this->set('posts', $this->Group->find('all',array('conditions'=>array('userid'=>$userid))));

	}
	
	public function addgroup(){
	
	//$userid=$this->Auth->user('id');
	$this->layout='user';
	
	 if ($this->request->is('post')) {
           // $this->Pnew->create();
$this->request->data['Group']['userid']=$this->Auth->user('id');
			
			//print_r($this->data);exit;
            if ($this->Group->save($this->request->data)) {
                $this->Session->setFlash(__('Your post has been saved.'));
                return $this->redirect(array('action' => 'usergroup'));
            }
            $this->Session->setFlash(__('Unable to add your post.'));
        }
	}
	
	
	public function delete($id) {
   

    if ($this->Group->delete($id)) {
        $this->Session->setFlash(
            __('The Group with id: %s has been deleted.', h($id))
        );
        return $this->redirect(array('action' => 'index'));
    }
}
	
	
	public function usergroupdelete($id){
	
	 if ($this->Group->delete($id)) {
        $this->Session->setFlash(
            __('The Group with id: %s has been deleted.', h($id))
        );
        return $this->redirect(array('action' => 'index'));
    }
	
	}
	
	public function addusergroup(){
	$this->layout='user';
	}
}
