<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class PnewsissuesController extends AppController {

/**
 * Controller name
 *
 * @var string
 */
	public $name = 'Pnewsissue';

/**
 * This controller does not use a model
 *
 * @var array
 */
	public $uses = array('Pnewsissue','Category','Group','Pnew');

	public function beforeFilter() {
        parent::beforeFilter();
        
		$this->Auth->allow(array('display','home'));
		
		
    }

/**
 * Displays a view
 *
 * @param mixed What page to display
 * @return void
 */
 public function index($pnewid){	

$this->layout='user'; 
 $this->set('pnewid',$pnewid);

$userid=$this->Auth->user('id');
$this->set('userid',$this->Auth->user('id'));

//$userid=$this->Auth->user('id');

$this->set('results', $this->Pnew->find('all',array('conditions'=>array('Pnew.userid'=>$userid))));
$newsletterdata= $this->Pnew->find('first',array('conditions'=>array('Pnew.id'=>$pnewid)));
//print_r($newsletterdata);
$this->set('pnewtitle',$newsletterdata['Pnew']['title']);
//$this->Pnew->find('all',array('conditions'=>array('Pnew.userid'=>$userid))));

$this->set('posts', $this->Pnewsissue->find('all',array('conditions'=>array('Pnewsissue.pnewid'=>$pnewid))));

		}
		
	public function add() {	
$this->layout='user';	
 //$this->set('pnewid',$pnewid);
$this->set('userid',$this->Auth->user('id'));

 if ($this->request->is('post')) {
         
                $this->request->data['Pnewsissue']['userid']=$this->Auth->user('id');
			//print_r($this->data);exit;
            if ($this->Pnewsissue->save($this->request->data)) {
                $this->Session->setFlash(__('Your Newsletter Issue has been saved.'));
                return $this->redirect(array('action' => 'index',$this->request->data['Pnewsissue']['pnewid']));
            }
            $this->Session->setFlash(__('Unable to add your post.'));
        }
	}		
	
	public function listnews() {	
//$this->layout='user';	
$this->set('posts', $this->Pnewsissue->find('all',array('conditions'=>array('type'=>'Private'))));

	}		
	
	public function createadminnew() {	
//$this->layout='user';	
$this->set('userid',$this->Auth->user('id'));
 if ($this->request->is('post')) {
           // $this->Pnewsissue->create();
			
			//print_r($this->data);exit;
            if ($this->Pnewsissue->save($this->request->data)) {
                $this->Session->setFlash(__('Your post has been saved.'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash(__('Unable to add your post.'));
        }
	}


public function approve($id){

$newsid=$id;

$data=array('id'=>$newsid,'status'=>1);
$this->Pnewsissue->save($data);
$this->redirect(array('action' => 'listnews'));
}



public function reject($id){
$newsid=$id;

$data=array('id'=>$newsid,'status'=>2);
$this->Pnewsissue->save($data);

$this->redirect(array('action' => 'listnews'));

}	
	
	public function delete($id) {
   
    if ($this->Pnewsissue->delete($id)) {
        $this->Session->setFlash(
            __('The post with id: %s has been deleted.', h($id))
        );
        return $this->redirect(array('action' => 'listnews'));
    }
}

public function userdelete($id,$pnewid) {
   
    if ($this->Pnewsissue->delete($id)) {
        $this->Session->setFlash(
            __('The Newsletter Issue with id: %s has been deleted.', h($id))
        );
        return $this->redirect(array('action' => 'index',$pnewid));
    }
}


public function edit($id = null,$pnewid) {
   $this->layout='user';
//$userid=$this->Auth->user('id');

 $this->set('pnewid',$pnewid);
$this->set('userid',$this->Auth->user('id'));

    $post = $this->Pnewsissue->findById($id);
    
    if ($this->request->is('post')) {
        $this->Pnewsissue->id = $id;
        if ($this->Pnewsissue->save($this->request->data)) {
            $this->Session->setFlash(__('Your post has been updated.'));
             $this->redirect(array('action' => 'index',$this->request->data['Pnewsissue']['pnewid']));
        }
        $this->Session->setFlash(__('Unable to update your post.'));
    }

    if (!$this->request->data) {
        $this->request->data = $post;
    }
}

public function adminlistnewsissues($pnewid){
$this->set('posts', $this->Pnewsissue->find('all',array('conditions'=>array('Pnewsissue.pnewid'=>$pnewid))));

}	
}
