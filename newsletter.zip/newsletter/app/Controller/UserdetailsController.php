<?php
App::uses('AppController', 'Controller');

class UserdetailsController extends AppController {

	public $uses = array('User','Userdetail');
	 //public $components = array('File','Thumb');

 public function beforeFilter() {
        parent::beforeFilter();
       // $this->Auth->allow('register');
	   
    }
	
	public function index(){
	
	
	}
	
	public function userprofile(){
	$this->layout='user';
	$userid=$this->Auth->user('id');
	$this->set('userdata',$this->Userdetail->find('first',array('conditions'=>array('Userdetail.userid'=>$userid))));
	
	}
	
	public function edit($id=null){	
	//echo $userid;echo $id;
	$this->layout='user';
	$this->Userdetail->id = $id;	
				if (empty($this->data)) {
        $this->data = $this->Userdetail->read();
    } else {              
	
	
    if ($this->Userdetail->save($this->data)) {
            $this->Session->setFlash('Your Userdetail has been updated.');
            $this->redirect(array('controller'=>'userdetails','action' => 'userprofile'));
        }
    }
	
	}
	
	public function adminedit($id=null){	
	//echo $userid;echo $id;
	$this->layout='default';
	$this->Userdetail->id = $id;	
				if (empty($this->data)) {
        $this->data = $this->Userdetail->read();
    } else {              
	
	
    if ($this->Userdetail->save($this->data)) {
            $this->Session->setFlash('Your Userdetail has been updated.');
            $this->redirect(array('controller'=>'users','action' => 'listusers'));
        }
    }
	
	}
	
	
	
	
	public function imgupload(){
	$userid=$this->Auth->user('id');
	$this->set('userdata',$this->Userdetail->find('all',array('conditions'=>array('Userdetail.user_id'=>$userid))));
	
	if(!empty($this->data)){
		$file =  $this->uploadphoto_user();
		
	//move_uploaded_file ($this->request->data['Userdetail']['image']['tmp_name'], WWW_ROOT.'/img/usrimg/'.$this->request->data['Userdetail']['image']['name']);
	$userid=$this->Auth->user('id');
	
	$this->Userdetail->updateAll( array('Userdetail.image' =>"'".$file."'"),array('Userdetail.user_id ' => $userid)
);
	
	
	$this->Session->setFlash('Your Profile Image has been updated.');
            $this->redirect(array('controller'=>'users','action' => 'index'));
	}	
	
	}
	
	public function uploadphoto_user(){
  	    if ($this->request->data['Userdetail']['image']['name']!=''){
			$this->File->destPath =WWW_ROOT."img/usrimg";
			$hash =$this->File->createHashValue($this->request->data['Userdetail']['image']['tmp_name']); 
	   
			if(!empty($hash)){
				$ext = substr($this->request->data['Userdetail']['image']['type'],strpos($this->request->data['Userdetail']['image']['type'],"/")+1);
				if($ext == "jpeg") $ext = "jpg";
					$this->File->setFilename($this->request->data['Userdetail']['image']['name']);
					$file=$this->File->uploadFile($this->request->data['Userdetail']['image']['name'],$this->request->data['Userdetail']['image']['tmp_name']);
				   
				if($file){  
					@copy($this->File->destPath.'/'.$file,$this->File->destPath.'/thumb/thumb_'.$file);
					$mime='';
					$this->Thumb->getResized('thumb_'.$file, $mime, $this->File->destPath.'/thumb/', 110, 90, 'FFFFFF', true, true,$this->File->destPath.'/thumb/', false);
				}  
				return $file; 
			}
		}
	}
	
	public function view($userid=null,$id=null){		//echo $userid;echo $id;
	$this->data = $this->Olduserdetail->find('first',array('conditions'=>array('Olduserdetail.userid'=>$userid)));
   
	
	
	}
	public function userview($id){		
	$this->set('results',$this->Userdetail->find('first',array('conditions'=>array('Userdetail.id'=>$id))));
   
	
	
	}
	public function sruserview($id){		
	$this->set('results',$this->Userdetail->find('first',array('conditions'=>array('Userdetail.id'=>$id))));
   
	
	
	}
	
	public function photo($imgtype=null,$id=null){
	
	$this->layout='user';
	$this->set('imgtype',$imgtype);
	$this->set('userid',$id);
	
	if(!empty($this->data)){
	
	$id=$this->request->data['Userdetail']['userid'];
	
	$file = $this->request->data['Userdetail']['file'];
	
	
	
	if($this->request->data['Userdetail']['imgtype']=='new'){
	 
	 $data=array('id'=>$id,'newphoto'=>$file['name']);
	 $this->Userdetail->save($data);
	 move_uploaded_file($file['tmp_name'], WWW_ROOT . 'img/newphoto/' . $file['name']);
	 $this->Session->setFlash('Your New Profile Image has been updated.');
     $this->redirect(array('controller'=>'userdetails','action' => 'userprofile'));

	 
	 }else{

	 $data=array('id'=>$id,'oldphoto'=>$file['name']);
	 $this->Userdetail->save($data);
	 
	  move_uploaded_file($file['tmp_name'], WWW_ROOT . 'img/oldphoto/' . $file['name']);
$this->Session->setFlash('Your Old Profile Image has been updated.');
    	
	$this->redirect(array('controller'=>'userdetails','action' => 'userprofile'));

	 
	 }
	 

	}
	
	}
	
	public function delete($id) {
   

    if ($this->Userdetail->delete($id)) {
        $this->Session->setFlash(
            __('The Userdetail has been deleted.')
        );
         $this->redirect(array('controller'=>'users','action' => 'listusers'));
    }
}
	
	
	
}
