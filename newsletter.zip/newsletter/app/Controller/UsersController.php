<?php

App::import('Vendor', 'php-excel-reader/excel_reader2'); //import statement


class UsersController extends AppController {

	public $name = 'Users';

	//public $helpers = array('Xls');
	public $uses = array('User','Group');
	  //public $components = array('File','Thumb');

 public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow(array('register','userlogin','userregister','home','contact','example'));
    }

	public function index() {
		
	//echo $userid=$this->Auth->user('id');
	
	
	}
	public function home(){
	$this->layout='front';
	$this->set('groups',$this->Group->find('all'));
	
	}
	public function userdashboard(){
	$this->layout='user';
	
	}
	
	public function userprofile(){
	$this->layout='user';
	
	}
	
	public function userlogout(){
	//$this->layout='user';
	$this->Session->destroy();
			$this->Cookie->destroy();
			$this->Session->setFlash('Your Has been succesfull Logout.');
			$this->redirect(array('controller'=>'users','action'=>'userlogin'));
	}
	
	public function search(){
	//print_r($this->data);
	$this->set('eventdata',$this->Event->find('all',array('order'=>array('Event.id Desc'))));
	if(isset($this->data['lname']) && !empty($this->data['lname']) && isset($this->data['fname']) && !empty($this->data['fname'])) {
		
	$this->set('userdata',$this->Userdetail->find('all', array('conditions' => array("Userdetail.lname like '%".$this->data['lname']."%'","Userdetail.fname like '%".$this->data['fname']."%'"),'limit' => 10))); 
		}else if(isset($this->data['fname'])&&!empty($this->data['fname'])){
	 $this->set('userdata',$this->Userdetail->find('all', array('conditions' => array("Userdetail.fname like '%".$this->data['fname']."%'"),'limit' => 10))); 
		}else if(isset($this->data['lname'])&&!empty($this->data['lname'])){
	 $this->set('userdata',$this->Userdetail->find('all', array('conditions' => array("Userdetail.lname like '%".$this->data['lname']."%'"),'limit' => 10))); 
		}else if(isset($this->data['search'])&&(!empty($this->data['search']))){
		$this->set('userdata',$this->Userdetail->find('all',array('order'=>array('Userdetail.id Desc'))));        	
	   }
	}
	
	public function register() {
	if ($this->request->is('post')) {
	    //print_r($this->data);exit;
		$this->request->data['User']['role']='user';
		//$this->request->data['User']['password'] = md5($this->request->data['User']['password']);

        if ($this->User->save($this->request->data)) {
			
			//$this->request->data['Userdetail']['userid'] = $this->User->id;
			
            //$this->User->Userdetail->save($this->request->data);
		
		    $this->Session->setFlash('Your registeration Has been succesfull.');
			$this->redirect(array('controller'=>'users','action'=>'userlogin'));
            
        }
    }
	
	
	}
	
	public function userlogin(){
	$this->layout='front';
	
	if ($this->request->is('post')) {
		//$this->request->data['User']['password'] = md5($this->request->data['User']['password']);

			if ($this->Auth->login()) {
				$this->redirect(array('controller'=>'pnews','action'=>'index'));
			} else {
				$this->Session->setFlash(__('Invalid username or password, try again'));
			}
    }
	
	}
	
	public function single($id){
	
	
	
	
	}
	
	public function login() {
		if ($this->request->is('post')) {
		
			if ($this->Auth->login()) {
						
				if($this->Auth->user('role') == 'admin'){
				$this->redirect(array('action' => 'admin'));
				
    //$this->redirect(array('controller' => 'admins','action' => 'index'));
}    else{
     $this->redirect($this->Auth->redirect());
}
			} else {
				$this->Session->setFlash(__('Invalid username or password, try again'));
			}
    }
	
	}
	
	
	public function edit($id=null) {
	
			$this->User->id = $id;
				if (empty($this->data)) {
					$this->data = $this->User->read();
				} else {
					if ($this->User->save($this->data)) {
						$this->Session->setFlash('User Info has been updated.');
						$this->redirect(array('action' => 'listusers'));
					}
				}

    }
	
	public function pendingusers(){
	
	$this->set('pendingrequests',$this->User->find('all',array('conditions'=>array('User.status'=>0,'User.role'=>'user'))));
	
	
	
	}
	
	public function listusers(){
	//$this->User->find('all', array('conditions' => array('not' => array('User.site_url'))));
	$this->set('requests',$this->User->find('all',array('conditions'=>array("User.role"=>"user"))));
	
	if(!empty($this->data)){
	//print_r($this->data);exit;
	
	if($this->data['searchoption']=='name'){
	 $this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.name) like '%".$this->data['searchfield']."%'"),'limit' => 10))); 
		
		}elseif($this->data['searchoption']=='postcode'){
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.postcode) like '%".$this->data['searchfield']."%'"),'limit' => 10))); 
		
		}elseif($this->data['searchoption']=='city'){
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.city) like '%".$this->data['searchfield']."%'"),'limit' => 10))); 
		
		}elseif($this->data['searchoption']=='country'){
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.country) like '%".$this->data['searchfield']."%'"),'limit' => 10))); 
		
		}elseif($this->data['searchoption']=='year'){
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.startyear) like '%".$this->data['searchfield']."%'"),'limit' => 10))); 
		
		}else{
		$this->Session->setFlash('Select option to search the data.');
						
		}
	}
	
	}
	
	public function status($id){
	
	$data=array('id'=>$id,'status'=>1);
	$this->User->save($data);
	$this->redirect(array('action' => 'pendingusers'));
	}
	
	public function statusde($id){
	
	$data=array('id'=>$id,'status'=>0);
	$this->User->save($data);
	$this->redirect(array('controller'=>'pnews','action' => 'listnews'));
	
	}
	
	public function delete($id = null) {
                $this->User->id = $id;
        
        if ($this->User->delete()) {
            $this->Session->setFlash(__('User deleted'));
            return $this->redirect(array('action' => 'listusers'));
        }
        $this->Session->setFlash(__('User was not deleted'));
        return $this->redirect(array('action' => 'listusers'));
    }

	public function add(){
	
	if ($this->request->is('post')) {
            $this->User->create();
            if ($this->User->save($this->request->data)) {
                $this->Session->setFlash(__('The user has been saved'));
                return $this->redirect(array('action' => 'listusers'));
            }
            $this->Session->setFlash(
                __('The user could not be saved. Please, try again.')
            );
        }
	
	}
	public function admin(){
	
	
	}
	public function usersevent($eventid){
	
	//echo $eventid;
	$this->set('requests',$this->Userevent->find('all',array('conditions'=>array('Userevent.eventid'=>$eventid))));
	}
	

	public function logout() {
		$this->Session->destroy();
			$this->Cookie->destroy();
		$this->redirect($this->Auth->logout());
	}
	public function adminlogout() {
		$this->Session->destroy();
			$this->Cookie->destroy();
		$this->redirect(array('action' => 'login'));
	}
	
    public function invite(){
	$this->layout='user';
	//print_r($this->data);
	//mail('mrvstech@hotmail.com', 'demo', 'hiii', 'ervg001@gmail.com');
	if(!empty($this->data)){
	
	//print_r($this->data);exit;
	$i=0;
	foreach($this->data['User']['email'] as $email){
	 $fromemail=$this->Auth->user('username');
	//exit;
	//$email;
	$name=$this->data['User']['name'][$i];
	
	if(!empty($email)){
 $to      = $email;
$subject = 'Freind Invitation For UNIVERSITY PUTRA MALAYSIA ALUMNI';
$message = 'Dear  '.$name.'Kindly visit http://upm-alumni.com/ to join University Alumni';
//$headers = 'From:' .$fromemail. "\r\n" .
    

 mail("$to", "$subject", "$message", "$fromemail");

	
	}
	
	
	$i++;
	}
	$this->Session->setFlash(__('Invitations send'));
	$this->redirect(array('controller'=>'users','action'=>'userdashboard'));
			
				
	
	}
	
	}
	
	public function result(){
	
		//print_r($this->data);exit;
		
	$this->layout=false;
	
	if($this->data['searchoption']=='name'){
	$this->set('search','Name');
	$this->set('requests',$this->Userdetail->find('all',array('order' => array('Userdetail.name ASC'))));
	
	}elseif(($this->data['searchoption']=='faculty')){
	$this->set('search','Faculty');
	$this->set('requests',$this->Userdetail->find('all',array('order' => array('Userdetail.faculty ASC'))));
	}elseif(($this->data['searchoption']=='city')){
	$this->set('search','City');
	$this->set('requests',$this->Userdetail->find('all',array('order' => array('Userdetail.city ASC'))));
	}elseif(($this->data['searchoption']=='state')){
	$this->set('search','State');
	$this->set('requests',$this->Userdetail->find('all',array('order' => array('Userdetail.state ASC'))));
	}elseif(($this->data['searchoption']=='country')){
	$this->set('search','Country');
	$this->set('requests',$this->Userdetail->find('all',array('order' => array('Userdetail.countrty ASC'))));
	}elseif(($this->data['searchoption']=='year')){
	$this->set('search','Year');
	$this->set('requests',$this->Userdetail->find('all',array('order' => array('Userdetail.startyear ASC'))));
	}
	
	
	
	}
	
	public function reports(){
	

	$this->set('requests',$this->User->find('all',array('conditions'=>array("User.role"=>"user"))));
	
	
	}
	
	public function frsearch(){
	$this->layout="user";
	//$this->User->find('all', array('conditions' => array('not' => array('User.site_url'))));
	$this->set('requests',$this->User->find('all',array('conditions'=>array("User.role"=>"user"),'order'=>array('Userdetail.name ASC'))));
	
	if(!empty($this->data)){
	//print_r($this->data);exit;
	
	if($this->data['searchoption']=='name'){
	if(!empty($this->data['searchfield'])){
	//echo $this->data['searchfield'];exit;
	 $this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.name) like '%".$this->data['searchfield']."%'"),'order'=>array('Userdetail.name ASC'),'limit' => 10))); 
		}else{
		
	$this->set('requests',$this->Userdetail->find('all', array('conditions'=>array("User.role"=>"user"),'order'=>array('Userdetail.name ASC'),'limit' => 10))); 
	//$result=$this->Userdetail->find('all', array('order'=>array('Userdetail.name ASC'),'limit' => 10));
	//print_r($result);
	//echo $this->data['searchfield'];exit;
		
		}
		}elseif($this->data['searchoption']=='postcode'){
		if(!empty($this->data['searchfield'])){
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.postcode) like '%".$this->data['searchfield']."%'"),'order'=>array('Userdetail.postcode ASC'),'limit' => 10))); 
		}else{
		
	$this->set('requests',$this->Userdetail->find('all', array('conditions'=>array("User.role"=>"user"),'order'=>array('Userdetail.postcode ASC'),'limit' => 10))); 
		
		}
		}elseif($this->data['searchoption']=='city'){
		if(!empty($this->data['searchfield'])){
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.city) like '%".$this->data['searchfield']."%'"),'order'=>array('Userdetail.city ASC'),'limit' => 10))); 
		}else{
		
	$this->set('requests',$this->Userdetail->find('all', array("User.role"=>"user",'order'=>array('Userdetail.city ASC'),'limit' => 10))); 
		
		}
		}elseif($this->data['searchoption']=='country'){
	if(!empty($this->data['searchfield'])){
	
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.country) like '%".$this->data['searchfield']."%'"),'order'=>array('Userdetail.country ASC'),'limit' => 10))); 
	}else{
	$this->set('requests',$this->Userdetail->find('all', array('conditions'=>array("User.role"=>"user"),'order'=>array('Userdetail.country ASC'),'limit' => 10))); 
	
	}	
		}elseif($this->data['searchoption']=='year'){
	if(!empty($this->data['searchfield'])){
	
	$this->set('requests',$this->Userdetail->find('all', array('conditions' => array("(Userdetail.startyear) like '%".$this->data['searchfield']."%'"),'order'=>array('Userdetail.startyear ASC'),'limit' => 10))); 
	}else{
	$this->set('requests',$this->Userdetail->find('all', array('conditions'=>array("User.role"=>"user"),'order'=>array('Userdetail.startyear ASC'),'limit' => 10))); 
	
	}	
		}elseif($this->data['searchoption']==''){
		$this->set('requests',$this->User->find('all',array('conditions'=>array("User.role"=>"user"),'order'=>array('Userdetail.name ASC'))));
	
		//$this->Session->setFlash('Select option to search the data.');
						
		}
	}
	
	}
	
	public function userview($id){
	
	$this->set('userdetail',$this->User->find('first',array('conditions'=>array('id'=>$id))));
	
	}
	public function sruserview(){
	
	
	
	}
	
	public function contact(){
	
	$this->layout="front";
	}
 
 
    public function example(){
	
	// to avoid having to tweak the contents of
        // $data you should use your db field name as the heading name
        // eg: Post.id, Post.title, Post.description
 
        // set the filename to read CSV from
        //$ = TMP . 'uploads' . DS . 'Post' . DS . ;
         $path=WWW_ROOT . 'list.xls';

        // read each data row in the file
       $data = new Spreadsheet_Excel_Reader($path, true); 
$temp = $data->dumptoarray(); 
         $this->set('result',$temp);
       
       
    
}

}
